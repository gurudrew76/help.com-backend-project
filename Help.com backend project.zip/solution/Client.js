'use strict';

const net = require('net');
const { fork } = require('child_process');
const parseStr = require('./Utils/parseStr');

class Client {
 // Constructor
 constructor(port, address, user) {
  this.socket = new net.Socket();
  this.address = address || serverIPAddress;
  this.user = user;
  this.loginSuccess = false;
  this.port = port || serverPortNumber;
  this.heartbeatInterval = 2000;
  this.previousEpoch = 0;
  this.curentEpoch = 0;
  this.maxRandom = 30;
  this.initializeClient();
  this.initializeChildProcess();
 }

 initializeChildProcess(){
  const forked = fork('childProcess.js');
  forked.on('message', (msg) => {
  });
  forked.send({ "port" : this.port, "ipaddress" :  this.address, "user" : this.user});
}

// Heartbeat implementation - If client didn't receive heartbeat within
// two seconds, client reconnects to server and logs in again.
//  using socket.end() method, which emits close event.
 checkForHeartBeat(epoch){
    //first heartbeat
   if(this.previousEpoch === 0 ) {
     this.previousEpoch = epoch;
     this.currentEpoch = epoch;
     return;
   }
   //subsequent heartbeats
   this.currentEpoch = epoch;
   let elapsed = this.currentEpoch - this.previousEpoch;
   if (elapsed>this.heartbeatInterval) {
    this.previousEpoch = this.currentEpoch;
    //console.log("ending socket");
    this.socket.end();
   }
 }

 // Initialize client
 initializeClient() {
  let client = this;
  client.socket.connect(client.port, client.address, () => {
    //login/relogin to server
    let jsonObj = { "name" : this.user};
    client.socket.write(JSON.stringify(jsonObj));
  });

  // Process data sent by server
  client.socket.on('data', (data) => {
    let jsonObj=parseStr(data.toString());
    for (let i=0; i<jsonObj.length; i++) {
      if (jsonObj[i].err!=true) {
        if (jsonObj[i].type==='heartbeat') {
          //console.log('RANDOM MESSAGE FROM SERVER : ' + jsonObj[i].epoch);
          this.checkForHeartBeat(jsonObj[i].epoch);
        } else if (jsonObj[i].type==='welcome') {
          this.loginSuccess = true;
          console.log('Login Successful : ' + jsonObj[i].msg);
        }
      }
      else {
        //console.log("Error occured : Invalid JSON");
      }
    }
  });

  // Implements logic for socket.end() which is called
  // if server dooesn't send heartbeat message within
  // two seconds
  // 1. Create new Socket
  // 2. Initialize client again
  // 3. Login to server again
  client.socket.on('close', () => {
   //console.log('Client closed');
    setTimeout( () => {
      this.socket = new net.Socket();
      this.initializeClient();
    }, this.heartbeatInterval);
  });

  // Error Handler
  client.socket.on('error', (err) => {
   //console.error(err);
  });

 }
}

module.exports = Client;
