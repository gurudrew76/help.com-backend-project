function parseStr(str) {

  str = str.replace(/(\r\n|\n|\r)/gm,"");

  let strArr = [];
  let arr = str.split("}{");
  let flag = true;
  if( arr.length > 1 ){
    for(let i=0; i<arr.length; i++){
        let curStr = "";
        if( i == 0 ){
          curStr = arr[i] + "}";
          strArr.push(curStr);
        }else if(i == (arr.length-1) ){
          curStr = "{" + arr[i];
          strArr.push(curStr);
        }else{
          curStr = "{" + arr[i] + "}";
          strArr.push(curStr);
        }
    }
  }else{
    strArr[0] = arr[0];
  }

  let arrJSONObj = [];
  for(let i=0; i<strArr.length; i++){
    let currentJSONStr = strArr[i];
    try{
      let currentJSONObj = JSON.parse(currentJSONStr);

        /*/ Debug -- print count, time and random
        for(let key in currentJSONObj){
          if (currentJSONObj.hasOwnProperty(key)) {
            if( key == "msg"){
              if( currentJSONObj[key]["count"] ){
                console.log("msg.count = " + currentJSONObj[key]["count"]);
              }
              if( currentJSONObj[key]["time"] ){
                console.log("msg.time = " + currentJSONObj[key]["time"]);
              }
              if( currentJSONObj[key]["random"] ){
                console.log("msg.random = " + currentJSONObj[key]["random"]);
              }
            }
          }
        }
        */

        arrJSONObj.push(currentJSONObj);
    } catch(e){
      let currentJSONObj = {"err":true};
      arrJSONObj.push(currentJSONObj);
    }
  }
  return arrJSONObj;
}

module.exports  = parseStr;
