'use strict';

const net = require('net');
const readline = require('readline');
const parseStr = require('./Utils/parseStr');

function validateInputJSON(str) {
  let arr = str.split("{");
  let strArr = [];
  let resultsArr = []
  for(let i=1; i<arr.length; i++){
    //console.log("{" + arr[i]);
    let curStr = "{" + arr[i];
    strArr.push(curStr);
  }

  for(let i=0; i<strArr.length; i++){
    let currentJSONStr = strArr[i];
    let currentJSONObj = JSON.parse(currentJSONStr);
    //console.log("currentJSONObj Properties and Values: ");
    for (let key in currentJSONObj) {
      if (currentJSONObj.hasOwnProperty(key)) {
      // for testing -- filter out any
      // message that doesn't has 'request' key
      if( key === 'request' ){
        resultsArr.push(strArr[i]);
      }
        //console.log(key + " -> " + currentJSONObj[key]);
      }
    }
  }
  return resultsArr[0];
}

process.on('message', (msg) => {
  // Enter JSON request after CMD>
  let rl = readline.createInterface(process.stdin, process.stdout);
  rl.setPrompt('CMD> ');
  rl.prompt();

 // Initialize client
  let socket = new net.Socket();
  socket.connect(msg.port, msg.ipaddress, () => {
    //login/relogin to server
    let jsonObj = { "name" : msg.user};
    socket.write(JSON.stringify(jsonObj));
  });

  // Process data sent by server
  socket.on('data', (data) => {
    let jsonObj=parseStr(data.toString());
    for (let i=0; i<jsonObj.length; i++) {
      if( jsonObj[i].type === "heartbeat" ){}
      else {
        if (jsonObj[i].err!=true) {
          if( jsonObj[i].msg.count != undefined ){
            console.log(JSON.stringify(jsonObj[i]));
            rl.prompt();
          }
          else if (jsonObj[i].msg.time  != undefined ) {
            console.log(JSON.stringify(jsonObj[i]));
            if(jsonObj[i].msg.random > 30 ){
              console.log("Random number is greater than 30");
            }
            rl.prompt();
          }
        }
      }
    }
  });

  socket.on('close', () => {
   //console.log('Client closed');
  });

  // Error Handler
  socket.on('error', (err) => {
   //console.error(err);
  });

  rl.on('line', function(line) {
      let str = line.trim();
      let str1 = validateInputJSON(str);
      // Read JSON as string. Validate jsonObj
      // Data is validated before it is sent server
      // See attached output.pdf file
      try{
        let jsonObj = JSON.parse(str);
        socket.write(JSON.stringify(jsonObj));
      }catch(e){
        rl.prompt();
      }
  }).on('close', function() {
      console.log('Done!');
      process.exit(0);
  });

});
